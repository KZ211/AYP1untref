# Fuente-Metal-Slug-Latino
Para ir subiendo la fuente con los cambios que le vaya haciendo. Por fin la fuente será de uso libre para todos.
